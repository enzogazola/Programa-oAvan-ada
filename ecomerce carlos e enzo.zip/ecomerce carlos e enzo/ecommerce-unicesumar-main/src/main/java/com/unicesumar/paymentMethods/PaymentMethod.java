package com.unicesumar.paymentMethods;

public interface PaymentMethod {
    String pay(double amount);
}