package com.unicesumar.paymentMethods;

import java.util.UUID;

public class PixPayment implements PaymentMethod {
    @Override
    public String pay(double amount) {
        String transactionId = UUID.randomUUID().toString().substring(0, 8) + "-" + 
                               UUID.randomUUID().toString().substring(0, 4) + "-" +
                               UUID.randomUUID().toString().substring(0, 4) + "-" +
                               UUID.randomUUID().toString().substring(0, 8);
        
        System.out.println("Pagamento confirmado com sucesso via PIX. Chave de Autenticação: " + transactionId);
        return transactionId;
    }
}