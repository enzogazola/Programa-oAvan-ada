package com.unicesumar.paymentMethods;

import java.util.UUID;

public class BoletoPayment implements PaymentMethod {
    @Override
    public String pay(double amount) {
        String transactionId = "BOL" + UUID.randomUUID().toString().substring(0, 8) + 
                               UUID.randomUUID().toString().substring(0, 4);
        
        System.out.println("Pagamento confirmado com sucesso via Boleto.");
        System.out.println("Código de Barras: " + transactionId);
        return transactionId;
    }
}