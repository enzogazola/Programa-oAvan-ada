package com.unicesumar.paymentMethods;

import java.util.UUID;

public class CreditCardPayment implements PaymentMethod {
    @Override
    public String pay(double amount) {
        String transactionId = "CC-" + UUID.randomUUID().toString().substring(0, 12);
        
        System.out.println("Pagamento confirmado com sucesso via Cartão de Crédito.");
        System.out.println("Código de Autorização: " + transactionId);
        return transactionId;
    }
}